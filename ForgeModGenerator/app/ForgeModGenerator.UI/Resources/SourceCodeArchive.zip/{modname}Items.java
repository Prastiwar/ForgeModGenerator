package com.{organization}.{modnamelower};

import java.util.ArrayList;
import java.util.List;

import com.{organization}.{modnamelower}.{modname}Hook;
import com.{organization}.{modnamelower}.item.ItemBase;
import com.{organization}.{modnamelower}.item.armor.ArmorBase;
import com.{organization}.{modnamelower}.item.bow.BowBase;
import com.{organization}.{modnamelower}.item.tool.*;

import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemSword;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;;

public class {modname}Items {

	public static final List<Item> ITEMS = new ArrayList<Item>();

	public static final Item {modname}LOGO = new ItemBase("{modname}logo");

	//{generator}

}
