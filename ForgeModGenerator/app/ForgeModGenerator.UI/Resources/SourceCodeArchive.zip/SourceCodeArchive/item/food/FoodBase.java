package com.{organization}.{modnamelower}.item.food;

import com.{organization}.{modnamelower}.{modname};
import com.{organization}.{modnamelower}.gui.{modname}CreativeTab;
import com.{organization}.{modnamelower}.{modname}Items;
import com.{organization}.{modnamelower}.interface.IHasModel;

import net.minecraft.item.ItemFood;

public class FoodBase extends ItemFood implements IHasModel {

	public FoodBase(String name, int amount, float saturation, boolean isAnimalFood) {
		super(amount, saturation, isAnimalFood);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab({modname}CreativeTab.MODCEATIVETAB);

		{modname}Items.ITEMS.add(this);
	}

	@Override
	public void registerModels() {
		{modname}.getProxy().registerItemRenderer(this, 0, "inventory");
	}

}
