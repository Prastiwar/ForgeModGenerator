package com.{organization}.{modnamelower}.gui;

import com.{organization}.{modnamelower}.{modname}Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class {modname}CreativeTab {

	public static final CreativeTabs MODCEATIVETAB = new CreativeTabs("{modname}") {
		@SideOnly(Side.CLIENT)
		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack({modname}Items.{modname}LOGO, 1);
		}

		@SideOnly(Side.CLIENT)
		@Override
		public boolean hasSearchBar() {
			return true;
		}
	};

}
