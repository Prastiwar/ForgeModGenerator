package com.{organization}.{modnamelower}.enchant;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.inventory.EntityEquipmentSlot;

public class EnchantBase extends Enchantment {

	public EnchantBase(String name, Enchantment.Rarity rarityIn, EnumEnchantmentType typeIn, EntityEquipmentSlot[] slots) {
		super(rarityIn, typeIn, slots);
		setName(name);
		setRegistryName(name);
		// {modname}Enchants.ENCHANTS.add(this);
	}

}
