package com.{organization}.{modnamelowerlower};

import java.util.ArrayList;
import java.util.List;

import net.minecraft.util.SoundEvent;

public class {modname}Sounds {

	public static final List<SoundEvent> SOUNDS = new ArrayList<SoundEvent>();

	//{generator}

}
