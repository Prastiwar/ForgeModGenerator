package com.{organization}.{modnamelower}.block;

import java.util.Random;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

public class OreBase extends BlockBase {

	protected Item dropItem;

	public OreBase(String name, Material material) {
		super(name, material);
	}

	@Override
	public Item getItemDropped(IBlockState state, Random rand, int fortune) {
		return dropItem;
	}

	@Override
	public int quantityDropped(Random rand) {
		int max = 4;
		int min = 1;
		return rand.nextInt(max) + min;
	}

	public OreBase setDropItem(Item item) {
		dropItem = item;
		return this;
	}
}
