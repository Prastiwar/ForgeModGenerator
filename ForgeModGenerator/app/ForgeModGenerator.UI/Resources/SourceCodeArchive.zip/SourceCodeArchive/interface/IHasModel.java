package com.{organization}.{modnamelower}.interface;

public interface IHasModel {

	public void registerModels();

}
