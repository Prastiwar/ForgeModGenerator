package com.{organization}.{modnamelower};

import java.util.ArrayList;
import java.util.List;

import com.{organization}.{modnamelower}.block.*;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class {modname}Blocks {

	public static final List<Block> BLOCKS = new ArrayList<Block>();

	//{generator}

}
