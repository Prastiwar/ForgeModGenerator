package com.{organization}.{modnamelower};

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

import com.{organization}.{modnamelower}.{modname}Recipes;
import com.{organization}.{modnamelower}.proxy.CommonProxy;

import org.apache.logging.log4j.Logger;

@Mod(modid = {modname}Hook.MODID, name = {modname}Hook.NAME, version = {modname}Hook.VERSION, acceptedMinecraftVersions = {modname}Hook.ACCEPTEDVERSIONS)
public class {modname} {

    @Instance
    private {modname} instance;

    @SidedProxy(clientSide = {modname}Hook.CLIENTPROXYCLASS, serverSide = {modname}Hook.SERVERPROXYCLASS)
    private static CommonProxy proxy;

    private static Logger logger;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        // GameRegistry.registerWorldGenerator(new {modname}WorldGen(), 3);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        {modname}Recipes.init();
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {

    }

    @EventHandler
    public void serverStart(FMLServerStartingEvent event) {

    }

    public static CommonProxy getProxy() {
        return proxy;
    }

}
