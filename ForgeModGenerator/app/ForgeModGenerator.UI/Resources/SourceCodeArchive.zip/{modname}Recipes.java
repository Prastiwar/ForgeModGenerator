package com.{organization}.{modnamelower};

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class {modname}Recipes {

	public static void init() {

		//{generator}

	}

}
