package com.{organization}.{modnamelower}.item.bow;

import com.{organization}.{modnamelower}.{modname};
import com.{organization}.{modnamelower}.gui.{modname}CreativeTab;
import com.{organization}.{modnamelower}.{modname}Items;
import com.{organization}.{modnamelower}.interface.IHasModel;

import net.minecraft.item.ItemBow;

public class BowBase extends ItemBow implements IHasModel {

	public BowBase(String name) {
		super();
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab({modname}CreativeTab.MODCEATIVETAB);
		{modname}Items.ITEMS.add(this);
	}

	@Override
	public void registerModels() {
		{modname}.getProxy().registerItemRenderer(this, 0, "inventory");
	}

}
