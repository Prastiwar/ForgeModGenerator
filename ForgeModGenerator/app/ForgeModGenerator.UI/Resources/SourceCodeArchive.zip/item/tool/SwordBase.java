package com.{organization}.{modnamelower}.item.tool;

import com.{organization}.{modnamelower}.{modname};
import com.{organization}.{modnamelower}.gui.{modname}CreativeTab;
import com.{organization}.{modnamelower}.{modname}Items;
import com.{organization}.{modnamelower}.interface.IHasModel;

import net.minecraft.item.ItemSword;

public class SwordBase extends ItemSword implements IHasModel {

	public SwordBase(String name, ToolMaterial material) {
		super(material);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab({modname}CreativeTab.MODCEATIVETAB);
		{modname}Items.ITEMS.add(this);
	}

	@Override
	public void registerModels() {
		{modname}.getProxy().registerItemRenderer(this, 0, "inventory");
	}

}
