package com.{organization}.{modnamelower};

public final class {modname}Hook {

	public static final String MODID = "{modid}";
	public static final String NAME = "{modname}";
	public static final String VERSION = "{modversion}";
	public static final String ACCEPTEDVERSIONS = "{mcversions}";

	public static final String CLIENTPROXYCLASS = "com.{organization}.{modnamelower}.proxy.ClientProxy";
	public static final String SERVERPROXYCLASS = "com.{organization}.{modnamelower}.proxy.ServerProxy";

}
