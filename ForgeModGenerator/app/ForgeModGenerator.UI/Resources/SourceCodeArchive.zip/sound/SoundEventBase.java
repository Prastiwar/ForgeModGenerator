package com.{organization}.{modnamelower};

import com.{organization}.{modnamelower}.{modname}Hook;
import com.{organization}.{modnamelower}.{modname}Sounds;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class XSoundEvent extends SoundEvent {

	public XSoundEvent(String name) {
		super(new ResourceLocation({modname}Hook.MODID, name));
		setRegistryName(name);
		{modname}Sounds.SOUNDS.add(this);
	}

}
